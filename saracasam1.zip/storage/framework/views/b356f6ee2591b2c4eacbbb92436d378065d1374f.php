<?php $__env->startSection('content'); ?>
    <table style="border:1px solid black; width:100%">
        
            <tr>
                <td><img width="30%" class="img-circle" src="<?php echo e(URL::asset($sar->imagepath)); ?>"></td>
            </tr>
        
    </table>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>