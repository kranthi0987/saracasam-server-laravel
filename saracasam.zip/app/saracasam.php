<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class saracasam extends Model
{
    //

    protected $fillable =[
        'imagename','imagepath','description','tag'

        ];


}
